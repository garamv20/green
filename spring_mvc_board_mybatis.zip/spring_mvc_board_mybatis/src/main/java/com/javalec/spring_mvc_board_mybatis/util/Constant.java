package com.javalec.spring_mvc_board_mybatis.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
	public static JdbcTemplate template;
}
