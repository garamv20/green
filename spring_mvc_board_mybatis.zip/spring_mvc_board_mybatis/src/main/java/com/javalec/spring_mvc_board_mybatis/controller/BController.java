package com.javalec.spring_mvc_board_mybatis.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javalec.spring_mvc_board_mybatis.dao.IBDao;
import com.javalec.spring_mvc_board_mybatis.util.Constant;



@Controller
public class BController {
//	BService service; //인터페이스 업캐스팅해서 자유롭게 사용하기 위해 
	
	public JdbcTemplate template;
	
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template = this.template;
	}

	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("@@@### list()");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		model.addAttribute("list", dao.list());
		
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view(Model model) {
		System.out.println("@@@### write_view()");
		
		return "write_view";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		System.out.println("@@@### write()");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.write(request.getParameter("bName")
				,request.getParameter("bTitle")
				,request.getParameter("bContent"));

//		request.getParameter("bName");
//		request.getParameter("bTitle");
//		request.getParameter("bContent");
		
		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request, Model model) {
		System.out.println("@@@### content_view()");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		model.addAttribute("content_view", dao.contentView(request.getParameter("bId")));
		
		return "content_view";
	}
	
	@RequestMapping("/modify")
	public String modify(HttpServletRequest request, Model model) {
		System.out.println("@@@### modify()");

		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.modify(request.getParameter("bName")
				,request.getParameter("bTitle")
				,request.getParameter("bContent")
				,request.getParameter("bId"));
//		model.addAttribute("request", request);
//		//service update 연결 
//		service = new BModifyService();
//		service.excute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		System.out.println("@@@### delete()");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.delete(request.getParameter("bId"));
//		model.addAttribute("request", request);
//		//삭제 서비스 연결
//		service = new BDeleteService();
//		service.excute(model);
		
		return "redirect:list";
	}
	
}
