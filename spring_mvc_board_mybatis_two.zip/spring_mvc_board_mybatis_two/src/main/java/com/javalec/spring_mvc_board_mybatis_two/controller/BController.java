package com.javalec.spring_mvc_board_mybatis_two.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.spring_mvc_board_mybatis_two.dto.BDto;
import com.javalec.spring_mvc_board_mybatis_two.service.BService;

@Controller
public class BController {
	@Autowired
	BService service; //인터페이스 업캐스팅해서 자유롭게 사용하기 위해 
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("@@@### list() start");
		
//		IBDao dao = sqlSession.getMapper(IBDao.class);
//		model.addAttribute("list", dao.list());
		ArrayList<BDto> list = service.list();
		model.addAttribute("list", list);
		
		System.out.println("@@@### list() end");
		
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view(Model model) {
		System.out.println("@@@### write_view()");
		
		return "write_view";
	}
	
	@RequestMapping("/write")
	public String write(@RequestParam HashMap<String, String> param, Model model) {
//	public String write(HttpServletRequest request, Model model) {
		System.out.println("@@@### write() start");
		
		service.write(param);

		System.out.println("@@@### write() end");
		
		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(@RequestParam HashMap<String, String> param, Model model) {
//	public String content_view(HttpServletRequest request, Model model) {
		System.out.println("@@@### content_view() start");
		
//		IBDao dao = sqlSession.getMapper(IBDao.class);
//		model.addAttribute("content_view", dao.contentView(request.getParameter("bId")));
		
		BDto dto = service.contentView(param);
		model.addAttribute("content_view", dto);
		
		System.out.println("@@@### content_view() start");
		return "content_view";
	}
	
	@RequestMapping("/modify")
	public String modify(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### modify() start");

//		IBDao dao = sqlSession.getMapper(IBDao.class);
//		dao.modify(request.getParameter("bName")
//				,request.getParameter("bTitle")
//				,request.getParameter("bContent")
//				,request.getParameter("bId"));
		
		service.modify(param);
		
		System.out.println("@@@### modify() end");
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### delete() strat");
		
//		IBDao dao = sqlSession.getMapper(IBDao.class);
//		dao.delete(request.getParameter("bId"));
		service.delete(param);
		
		System.out.println("@@@### delete() end");
		
		return "redirect:list";
	}
	
}
