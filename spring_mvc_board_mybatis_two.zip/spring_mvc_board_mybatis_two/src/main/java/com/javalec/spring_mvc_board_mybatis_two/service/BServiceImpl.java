package com.javalec.spring_mvc_board_mybatis_two.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.spring_mvc_board_mybatis_two.dao.IBDao;
import com.javalec.spring_mvc_board_mybatis_two.dto.BDto;

@Service("BService")
public class BServiceImpl implements BService{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<BDto> list() {
		System.out.println("@@@### BServiceImpl.list() start");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
//		model.addAttribute("list", dao.list());	
		ArrayList<BDto> list = dao.list();
		
		System.out.println("@@@### BServiceImpl.list() end");

		return list;
	}

	@Override
	public void write(HashMap<String, String> param) {
		System.out.println("@@@### BServiceImpl.write() start");
		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.write(param);
		System.out.println("@@@### BServiceImpl.write() end");
	}

	@Override
	public BDto contentView(HashMap<String, String> param) {
		System.out.println("@@@### BServiceImpl.contentView() start");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		BDto dto = dao.contentView(param);
		
		System.out.println("@@@### BServiceImpl.contentView() end");

		return dto;
	}

	@Override
	public void modify(HashMap<String, String> param) {
		System.out.println("@@@### BServiceImpl.modify() start");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.modify(param);
		
		System.out.println("@@@### BServiceImpl.modify() end");
		
	}

	@Override
	public void delete(HashMap<String, String> param) {
		System.out.println("@@@### BServiceImpl.delete() start");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		dao.delete(param);
		
		System.out.println("@@@### BServiceImpl.delete() end");
	}



}
