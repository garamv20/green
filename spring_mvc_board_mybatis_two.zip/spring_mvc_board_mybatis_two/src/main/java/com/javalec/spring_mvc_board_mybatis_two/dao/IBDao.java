package com.javalec.spring_mvc_board_mybatis_two.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.spring_mvc_board_mybatis_two.dto.BDto;


public interface IBDao {
	public ArrayList<BDto> list();
//	public void write(String bName,String bTitle,String bContent);
	public void write(HashMap<String, String> param);
	public BDto contentView(HashMap<String, String> param);
	public void modify(HashMap<String, String> param);
	public void delete(HashMap<String, String> param);
}
